---
layout: portfolio-slim
title: Projects
categories: test
tag: test
date: 2018-01-20
subtitle: "Personal Projects"
project:
- 
	"title": "Awesome Checklist Checklist"
	"subtitle": "A Curated List of Checklists"
	"date": "2017.12"
	"img_link": Awesome-Checklist-Checklist.png
	"project_link": http://checklist.yingjiehu.com/
	"button-text": "View"
	"use":
		- BootStrap
		- JavaScript
		- jQuery
		- Gulp
	"description": "Checklists included can span every field of life, such as programming, traveling, games. Over 1700 stars on GitHub. The website is automatically updated when I update README.md."
-
	"title": "Random Quote Machine"
	"subtitle": "Beatiful Chinese Sayings"
	"date": "2017.12"
	"img_link": random-quote-machine.png
	"project_link": http://randomquotemachine.yingjiehu.com/
	"button-text": "Open"
	"use":
		- BootStrap
		- JavaScript
		- jQuery
	"description": "The website randomly shows Chinese sayings from over one thousand years ago. The background color is changed every time"
---