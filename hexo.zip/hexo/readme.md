### 1.hexo 文章发布：

    $ hexo new "postName"  //生成文章文件
    
    # 编辑postName.md
    
    $ hexo generate //生成静态页面
    $ hexo deploy //将文章部署到Github
    
    返回博客地址，查看文章是否生成
    
### 2.hexo 安装主题：

    https://hexo.io/themes/    hexo 主题网站找到喜欢的theme
    找到主题项目 git 地址  https://github.com/iissnan/hexo-theme-next themes/next
    
    $ cd E:\hexo
    $ git clone https://github.com/iissnan/hexo-theme-next themes/next
    
    将blog目录下_config.yml里theme的名称landscape修改为next
    $ hexo clean //清除缓存文件 (db.json) 和已生成的静态文件 (public)
    $ hexo g //生成缓存和静态文件
    $ hexo d //重新部署到服务器
    