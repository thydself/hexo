"use strict";
(function ($) {
// Write your custom JavaScript code here.


})(jQuery);
